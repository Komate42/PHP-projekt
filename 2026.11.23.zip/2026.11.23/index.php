<?php
require_once 'classroom-data.php';
$classes = DATA['classes'];
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iskolanévsor</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        nav { margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #ccc; }
        nav button { padding: 8px 15px; margin-right: 10px; cursor: pointer; font-size: 15px; }
        .controls { margin-bottom: 20px; }
        table { border-collapse: collapse; width: 100%; max-width: 600px; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f4f4f4; }
    </style>
</head>
<body>
 
    <nav>
        <button type="button" id="btn-all-students">Teljes iskolanévsor</button>
        <button type="button" id="btn-class-students">Kiválasztott osztály tanulói</button>
    </nav>
 
    <div class="controls" id="class-selector-container">
        <label for="class-select"><strong>Válasszon osztályt:</strong></label>
        <select id="class-select">
            <option value="">-- Válasszon --</option>
            <?php foreach ($classes as $class): ?>
                <option value="<?= htmlspecialchars($class) ?>"><?= htmlspecialchars($class) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
 
    <div id="result-container">
        <p>Válasszon egy menüpontot vagy egy osztályt a lista megjelenítéséhez.</p>
    </div>
 
    <script src="app.js"></script>
</body>
</html>