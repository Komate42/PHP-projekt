<?php
require_once 'classroom-data.php';
 
header('Content-Type: application/json; charset=utf-8');
 
$action = $_GET['action'] ?? '';
$selectedClass = $_GET['class'] ?? '';
$roster = $_SESSION['school_roster'] ?? [];
 
if ($action === 'all') {
    $allStudents = [];
    foreach ($roster as $classStudents) {
        foreach ($classStudents as $student) {
            $allStudents[] = $student;
        }
    }
    echo json_encode(['status' => 'success', 'students' => $allStudents]);
    exit;
}
 
if ($action === 'class' && !empty($selectedClass)) {
    if (isset($roster[$selectedClass])) {
        echo json_encode(['status' => 'success', 'students' => $roster[$selectedClass]]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'A megadott osztály nem található.']);
    }
    exit;
}
 
echo json_encode(['status' => 'error', 'message' => 'Érvénytelen kérés vagy nincs kiválasztva osztály.']);