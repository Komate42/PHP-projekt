document.addEventListener('DOMContentLoaded', () => {
    const btnAll = document.getElementById('btn-all-students');
    const btnClass = document.getElementById('btn-class-students');
    const classSelect = document.getElementById('class-select');
    const classContainer = document.getElementById('class-selector-container');
    const resultContainer = document.getElementById('result-container');
 
    
    function fetchAndRenderStudents(url, title) {
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    renderTable(data.students, title);
                } else {
                    resultContainer.innerHTML = `<p style="color: red;">${data.message}</p>`;
                }
            })
            .catch(error => {
                console.error('Hiba történt:', error);
                resultContainer.innerHTML = '<p style="color: red;">Hiba történt az adatok betöltésekor.</p>';
            });
    }
 
    
    function renderTable(students, title) {
        if (!students || students.length === 0) {
            resultContainer.innerHTML = '<p>Nincsenek megjeleníthető tanulók.</p>';
            return;
        }
 
        let html = `<h3>${title} (${students.length} fő)</h3>`;
        html += `
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Vezetéknév</th>
                        <th>Keresztnév</th>
                        <th>Osztály</th>
                        <th>Nem</th>
                    </tr>
                </thead>
                <tbody>
        `;
 
        students.forEach((student, index) => {
            html += `
                <tr>
                    <td>${index + 1}.</td>
                    <td>${student.lastname}</td>
                    <td>${student.firstname}</td>
                    <td>${student.class}</td>
                    <td>${student.gender}</td>
                </tr>
            `;
        });
 
        html += '</tbody></table>';
        resultContainer.innerHTML = html;
    }
 
    
    btnAll.addEventListener('click', () => {
        classContainer.style.display = 'none';
        fetchAndRenderStudents('ajax.php?action=all', 'Teljes iskolanévsor');
    });
 
    
    btnClass.addEventListener('click', () => {
        classContainer.style.display = 'block';
        const selectedClass = classSelect.value;
        if (selectedClass) {
            fetchAndRenderStudents(`ajax.php?action=class&class=${encodeURIComponent(selectedClass)}`, `${selectedClass} osztály névsora`);
        } else {
            resultContainer.innerHTML = '<p>Kérjük, válasszon egy osztályt a fenti listából!</p>';
        }
    });
 
   
    classSelect.addEventListener('change', () => {
        const selectedClass = classSelect.value;
        if (selectedClass) {
            fetchAndRenderStudents(`ajax.php?action=class&class=${encodeURIComponent(selectedClass)}`, `${selectedClass} osztály névsora`);
        } else {
            resultContainer.innerHTML = '<p>Kérjük, válasszon egy osztályt a listából!</p>';
        }
    });
});