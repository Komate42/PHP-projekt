<?php
/**
* @author Kovács László
*
* Array usage practice
*/
 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
 
const DATA = [
    'lastnames' => [
        'Major',
        'Riz',
        'Kard',
        'Pum',
        'Víz',
        'Kandisz',
        'Patta',
        'Para',
        'Pop',
        'Remek',
        'Ének',
        'Szalmon',
        'Ultra',
        'Dil',
        'Git',
        'Har',
        'Külö',
        'Harm',
        'Zsíros B.',
        'Virra',
        'Kasza',
        'Budipa',
        'Bekre',
        'Fejet',
        'Minden',
        'Bármi',
        'Lapos',
        'Bor',
        'Mikorka',
        'Szikla',
        'Fekete',
        'Rabsz',
        'Kalim',
        'Békés',
        'Szenyo',
    ],
    'firstnames' => [
        'men' => ['Ottó', 'Pál', 'Elek', 'Simon', 'Ödön', 'Kálmán', 'Áron', 'Elemér', 'Szilárd', 'Csaba'],
        'women' => [
            'Anna', 'Virág', 'Nóra', 'Zita', 'Ella', 'Viola', 'Emma', 'Áron', 'Mónika', 'Dóra', 'Blanka',
            'Piroska', 'Lenke', 'Mercédesz', 'Olga', 'Rita',
        ]
    ],
    'classes' => [
        '11a', '11b', '11c', '12a', '12b', '12c',
    ],
    'subjects' => ['math', 'history', 'biology', 'chemistry', 'physics', 'informatics', 'alchemy', 'astrology'],
];
 

if (!isset($_SESSION['school_roster'])) {
    $roster = [];
 
    foreach (DATA['classes'] as $class) {
        
        $studentCount = rand(10, 15);
        $roster[$class] = [];
 
        for ($i = 0; $i < $studentCount; $i++) {
            
            $isGirl = (bool)rand(0, 1);
            $gender = $isGirl ? 'lány' : 'fiú';
 
            
            $lastname = DATA['lastnames'][array_rand(DATA['lastnames'])];
 
            
            if ($isGirl) {
                $firstname = DATA['firstnames']['women'][array_rand(DATA['firstnames']['women'])];
            } else {
                $firstname = DATA['firstnames']['men'][array_rand(DATA['firstnames']['men'])];
            }
 
            $roster[$class][] = [
                'lastname'  => $lastname,
                'firstname' => $firstname,
                'class'     => $class,
                'gender'    => $gender,
            ];
        }
    }
 
    $_SESSION['school_roster'] = $roster;
}